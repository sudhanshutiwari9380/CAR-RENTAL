from django.shortcuts import render, HttpResponse, redirect
from home.models import Contact, Car, Corder
from django.contrib.auth.models import User, AnonymousUser
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from PayTm import Checksum
from datetime import datetime
MERCHANT_KEY = "ZELy1lHj8PjUVGC4"
# Create your views here.


def about(request):
     return(render(request, 'about.html'))
    # return HttpResponse("This is about page")


def booking(request):
    if not request.user.is_authenticated:
        messages.warning(request, "Please Login and Try Again")
        return render(request, 'login.html')
    else:

        usern = request.user.username
        orders = []
        orders = Corder.objects.filter(name=usern)
        print(orders)

        params = {'orders': orders}
        return render(request, 'booking.html', params)
    return render(request, "booking.html")


def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc)
        contact.save()
    return render(request, 'contact.html')


def signup(request):
    if request.method == "POST":
        username = request.POST.get("username")
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        email = request.POST.get("email")
        pass1 = request.POST.get("pass1")
        pass2 = request.POST.get("pass2")
        if pass1 != pass2:
            messages.warning(request, "password is incorrect")
            return render(request, "index.html")
        myuser = User.objects.create_user(username, email, pass1)
        myuser.first_name = first_name
        myuser.last_name = last_name
        #customer=Customer(username=username,first_name=first_name,last_name=last_name,pass1=pass1)
        #customer.save()
        myuser.save()
        messages.success(request, "signup successfull")
        return redirect("/login")
    return render(request, "signup.html")


def handle_login(request):
    if request.method == "POST":
        loginusername = request.POST.get("username")
        loginpassword = request.POST.get("pass1")
        user = authenticate(username=loginusername, password=loginpassword)
        if user is not None:
            login(request, user)
            messages.warning(request, 'login Successsfull')
            cars = Car.objects.all()
            n = len(cars)
            params = {'car': cars, 'range': range(n)}
            return render(request, 'index.html', params)
        else:
            messages.success(request, 'Invalid credentials')
            return redirect("/login")

    return render(request, "login.html")


def index(request):
    # if not request.user.is_authenticated:
        # return redirect("/signup")
        cars = Car.objects.all()
        n = len(cars)
        params = {'car': cars, 'range': range(n)}
        return render(request, 'index.html', params)


def carlists(request, car_id):
    if not request.user.is_authenticated:
        return redirect("/login")
    car = Car.objects.filter(car_id=car_id)

    return render(request, "carlists.html", {"car": car[0]})


def handle_logout(request):
 logout(request)
 messages.warning(request, "successfully logged out")
 return redirect('/login')


def checkout(request):

    if request.method == "POST":
        amount = request.POST.get("amount")
        total=request.POST.get("total")
        name = request.POST.get('name')
        carname = request.POST.get("carname")
        email = request.POST.get('email')
        pickup_date = request.POST.get('pickup_date')
        drop_date = request.POST.get('drop_date')
        pickup_address = request.POST.get('pickup_address')
        phone = request.POST.get('phone')
        city = request.POST.get('city')
        state = request.POST.get('state')
        zip_code = request.POST.get('zip_code')
        corder = Corder(name=name, amount=amount,total=total, carname=carname, email=email, pickup_date=pickup_date,
                        drop_date=drop_date, pickup_address=pickup_address, phone=phone, city=city, state=state, zip_code=zip_code)
        date_format = "%Y-%m-%d"
        a = datetime.strptime(str(pickup_date), date_format)
        b = datetime.strptime(str(drop_date), date_format)
        delta = (b - a).days
        
        
        s=int(amount)
        corder.save()
        print(s*delta)
        Corder.objects.filter(Corder_id=corder.Corder_id).update(total=s*delta)
        
        param_dict={


            'MID': 'vPlGGR76942952091770',
            'ORDER_ID': str(corder.Corder_id),
            'TXN_AMOUNT': str(s*delta),
            'CUST_ID': 'email',
            'INDUSTRY_TYPE_ID': 'Retail',
            'WEBSITE': 'WEBSTAGING',
            'CHANNEL_ID': 'WEB',
            'CALLBACK_URL': 'http://127.0.0.1:8000/handlerequest',
        }
        param_dict['CHECKSUMHASH']=Checksum.generate_checksum(
            param_dict, MERCHANT_KEY)

        return render(request, 'paytm.html', {'param_dict': param_dict})
    return HttpResponse("this is checkout page")

@ csrf_exempt
def handlerequest(request):
    form=request.POST
    response_dict={}
    for i in form.keys():
        response_dict[i]=form[i]
        if i == 'CHECKSUMHASH':
            checksum=form[i]

    verify=Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
    if verify:
        if response_dict['RESPCODE'] == '01':
            print('order successful')


            gid=response_dict["ORDERID"]
            Corder.objects.filter(Corder_id=gid).update(paid=True)


        else:
            print('order was not successful because' + \
                  response_dict['RESPMSG'])
    return render(request, 'paymentstatus.html', {'response': response_dict})

#def Proceed_to_pay(request, Corder_id, amount):

    #param_dict={


            #'MID': 'vPlGGR76942952091770',
            #'TXN_AMOUNT': str(amount),
            #'CUST_ID': 'email',
            #'INDUSTRY_TYPE_ID': 'Retail',
            #'WEBSITE': 'WEBSTAGING',
            #'CHANNEL_ID': 'WEB',
            #'CALLBACK_URL': 'http://127.0.0.1:8000/handlerequest',
       # }
    #param_dict['CHECKSUMHASH']=Checksum.generate_checksum(
        #param_dict, MERCHANT_KEY)

    #return render(request, 'paytm.html', {'param_dict': param_dict})
    # return HttpResponse("vbhfb")
def cancel(request,sorder_id):
    Corder.objects.filter(Corder_id=sorder_id).delete()
    return redirect("/booking")
