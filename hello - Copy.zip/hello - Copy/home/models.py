from django.db import models
from django.utils.timezone import datetime


# Create your models here.
class Contact(models.Model):
    name=models.CharField(max_length=122)
    email=models.EmailField(max_length=122)
    phone=models.CharField(max_length=122)
    desc=models.TextField()
    def __str__(self):
        return self.name
class Car(models.Model):
    car_id=models.AutoField(primary_key="true")
    car_name=models.CharField(max_length=100)
    car_price=models.IntegerField()
    car_desc=models.CharField(max_length=5000)
    car_image=models.ImageField(upload_to="home/images")
    def __str__(self):
        return self.car_name


class Corder(models.Model):
    Corder_id=models.AutoField(primary_key="true")
    amount=models.IntegerField(default=0)
    name=models.CharField(max_length=100)
    carname=models.CharField(max_length=100,default="")
    email=models.EmailField(max_length=100)
    pickup_date=models.DateField()
    drop_date=models.DateField(default=datetime.now())
    pickup_address=models.CharField(max_length=100)
    phone=models.CharField(max_length=12)
    city=models.CharField(max_length=100,default="")
    state=models.CharField(max_length=100,default="")
    zip_code=models.CharField(max_length=100,default="")
    paid=models.BooleanField(default=False)
    total=models.IntegerField(default=0)
    def __str__(self):
        return self.name

    
